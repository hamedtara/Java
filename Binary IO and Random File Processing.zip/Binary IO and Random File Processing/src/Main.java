import dataPackage.RandomIO;
//Hamed tara-n01540404
//Garry mittal - n01552883
//Meghna Rajubhai Ramsnehi - n01514629
import presentationPackage.GUI;
import presentationPackage.GUI.*;
public class Main {
    // Defining the main method
    public static void main(String[] args) {
        // Creating an object of the GUI class
        GUI gui = new GUI();



    }
}